import HorizontalScroll from '@oberon-amsterdam/horizontal';

new HorizontalScroll();
